// Export the logger as the package entry point.
module.exports = require('./logger');